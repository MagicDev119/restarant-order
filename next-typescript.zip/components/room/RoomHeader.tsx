import styles from "../../styles/Home.module.css";
export const RoomHeader = () => (
  <div className={styles.subcontent}>
    <span className={styles.subtitle}>In the room service</span>
  </div>
);
