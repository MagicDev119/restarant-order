"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/products";
exports.ids = ["pages/api/products"];
exports.modules = {

/***/ "(api)/./pages/api/products/index.ts":
/*!*************************************!*\
  !*** ./pages/api/products/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    try {\n        const response = await fetch(\"https://api.airtable.com/v0/app13pSrFKlqNNCmM/nomenclature\", {\n            method: \"GET\",\n            headers: {\n                \"Authorization\": \"Bearer keySqCn1Ak8686gPe\"\n            }\n        });\n        const { records , error  } = await response.json();\n        if (records.length) {\n            res.status(200).json(records);\n            res.end();\n        } else {\n            res.status(404);\n            res.end();\n        }\n    } catch  {\n        res.status(500);\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcHJvZHVjdHMvaW5kZXgudHMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUVBLGlFQUFlLE9BQU9BLEtBQXFCQyxNQUF5QjtJQUNsRSxJQUFJO1FBQ0YsTUFBTUMsV0FBVyxNQUFNQyxNQUFNLDhEQUE4RDtZQUN6RkMsUUFBUTtZQUNSQyxTQUFTO2dCQUNQLGlCQUFpQjtZQUNuQjtRQUNGO1FBRUEsTUFBTSxFQUFFQyxRQUFPLEVBQUVDLE1BQUssRUFBRSxHQUFHLE1BQU1MLFNBQVNNLElBQUk7UUFFOUMsSUFBSUYsUUFBUUcsTUFBTSxFQUFFO1lBQ2xCUixJQUFJUyxNQUFNLENBQUMsS0FBS0YsSUFBSSxDQUFDRjtZQUNyQkwsSUFBSVUsR0FBRztRQUNULE9BQU87WUFDTFYsSUFBSVMsTUFBTSxDQUFDO1lBQ1hULElBQUlVLEdBQUc7UUFDVCxDQUFDO0lBQ0gsRUFBRSxPQUFNO1FBQ05WLElBQUlTLE1BQU0sQ0FBQztJQUNiO0FBQ0YsR0FBRSIsInNvdXJjZXMiOlsid2VicGFjazovL2ludGhlcm9vbS8uL3BhZ2VzL2FwaS9wcm9kdWN0cy9pbmRleC50cz85MjQzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5leHRBcGlSZXF1ZXN0LCBOZXh0QXBpUmVzcG9uc2UgfSBmcm9tICduZXh0JztcblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgKHJlcTogTmV4dEFwaVJlcXVlc3QsIHJlczogTmV4dEFwaVJlc3BvbnNlKSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnaHR0cHM6Ly9hcGkuYWlydGFibGUuY29tL3YwL2FwcDEzcFNyRktscU5OQ21NL25vbWVuY2xhdHVyZScsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciBrZXlTcUNuMUFrODY4NmdQZSdcbiAgICAgIH0sXG4gICAgfSlcbiAgICBcbiAgICBjb25zdCB7IHJlY29yZHMsIGVycm9yIH0gPSBhd2FpdCByZXNwb25zZS5qc29uKClcbiAgICBcbiAgICBpZiAocmVjb3Jkcy5sZW5ndGgpIHtcbiAgICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHJlY29yZHMpO1xuICAgICAgcmVzLmVuZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXMuc3RhdHVzKDQwNCk7XG4gICAgICByZXMuZW5kKCk7XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICByZXMuc3RhdHVzKDUwMCk7XG4gIH1cbn07XG4iXSwibmFtZXMiOlsicmVxIiwicmVzIiwicmVzcG9uc2UiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJyZWNvcmRzIiwiZXJyb3IiLCJqc29uIiwibGVuZ3RoIiwic3RhdHVzIiwiZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/products/index.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/products/index.ts"));
module.exports = __webpack_exports__;

})();