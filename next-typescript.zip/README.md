# intheroom
intheroom

Ресурсы:
1. [Дизайн](https://www.figma.com/file/ac8PkDc6hBfVMXpVzgvv0o/In-The-Room-Client-Front?node-id=72%3A7900&t=A65kMutAQ6ahG3qY-1)
2. [Дока по budibase](https://docs.budibase.com/docs) 
3. [Как засетапить проект BB + NextJs](https://budibase.com/blog/data/building-a-crud-app-with-budibase-and-next.js/)
